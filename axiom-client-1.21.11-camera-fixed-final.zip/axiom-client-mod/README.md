# Axiom Client 1.21.11 Enhanced

Fabric client utility project targeting Minecraft 1.21.11.

## Changes
- Minecraft 1.21.11 + Yarn 1.21.11+build.6
- Fabric Loader 0.19.3
- Fabric API 0.141.6+1.21.11
- Fixed the 1.21.11 KeyBinding constructor/category API.
- BaseFinder upgraded with:
  - loaded-chunk-only scanning (server friendly)
  - storage/utility evidence weighting
  - nearby obsidian/redstone/portal evidence
  - proximity/cluster scoring
  - configurable scan radius, interval, score threshold and render distance
  - ranked results and smaller focus markers for mobile readability
  - asynchronous scoring after a main-thread snapshot

## Important server limitation
BaseFinder can only analyze chunk/block-entity data that the client has actually received and loaded. It does not force-load chunks, bypass server-side protections, or retrieve hidden/unloaded server data.

## Suggested BaseFinder settings on iPhone
- radius: 12-16
- chunksPerCycle: 1-2
- intervalTicks: 15-20
- nearbyBlockScan: true
- minScore: 40
- renderDistance: 192-256
