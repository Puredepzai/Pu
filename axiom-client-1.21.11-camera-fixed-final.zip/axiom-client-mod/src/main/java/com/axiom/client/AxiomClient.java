package com.axiom.client;

import com.axiom.client.config.ConfigManager;
import com.axiom.client.core.ModuleManager;
import com.axiom.client.event.EventBus;
import com.axiom.client.gui.AxiomScreen;
import com.axiom.client.input.KeybindManager;
import com.axiom.client.network.NetworkManager;
import com.axiom.client.render.RenderManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

public final class AxiomClient implements ClientModInitializer {
    public static final String MOD_ID = "axiom";
    private static ModuleManager modules;
    private static ConfigManager config;
    private static EventBus events;
    private static RenderManager render;

    @Override
    public void onInitializeClient() {
        config = new ConfigManager();
        config.load();

        events = new EventBus();
        modules = new ModuleManager();
        render = new RenderManager();
        KeybindManager.init();
        NetworkManager.init();
        modules.registerDefaults();
        render.init();
        ClientTickEvents.END_CLIENT_TICK.register(AxiomClient::tick);
    }

    private static void tick(MinecraftClient client) {
        if (client.player == null) return;
        KeybindManager.tick(client);
        modules.tick(client);
        config.saveIfDirty();
    }

    public static ModuleManager modules() { return modules; }
    public static ConfigManager config() { return config; }
    public static EventBus events() { return events; }
    public static RenderManager render() { return render; }

    public static void openScreen() {
        MinecraftClient.getInstance().setScreen(new AxiomScreen(null));
    }
}
