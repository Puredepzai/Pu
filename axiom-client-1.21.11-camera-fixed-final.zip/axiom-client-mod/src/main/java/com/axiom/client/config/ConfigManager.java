package com.axiom.client.config;

import com.axiom.client.AxiomClient;
import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public final class ConfigManager {
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("axiom.json");
    private final JsonObject root = new JsonObject();
    private volatile boolean dirty;

    public void load() {
        try {
            if (Files.exists(file)) {
                JsonElement parsed = JsonParser.parseString(Files.readString(file));
                if (parsed.isJsonObject()) parsed.getAsJsonObject().entrySet().forEach(e -> root.add(e.getKey(), e.getValue()));
            }
        } catch (Exception ignored) {}
    }

    public synchronized void save() {
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(root),
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            dirty = false;
        } catch (IOException ignored) {}
    }

    public void saveIfDirty() { if (dirty) save(); }
    public void markDirty() { dirty = true; }

    public boolean getBoolean(String key, boolean fallback) {
        JsonElement e = root.get(key);
        return e != null && e.isJsonPrimitive() ? e.getAsBoolean() : fallback;
    }
    public int getInt(String key, int fallback) {
        JsonElement e = root.get(key);
        return e != null && e.isJsonPrimitive() ? e.getAsInt() : fallback;
    }
    public double getDouble(String key, double fallback) {
        JsonElement e = root.get(key);
        return e != null && e.isJsonPrimitive() ? e.getAsDouble() : fallback;
    }
    public String getString(String key, String fallback) {
        JsonElement e = root.get(key);
        return e != null && e.isJsonPrimitive() ? e.getAsString() : fallback;
    }
    public void set(String key, boolean value) { root.addProperty(key, value); markDirty(); }
    public void set(String key, int value) { root.addProperty(key, value); markDirty(); }
    public void set(String key, double value) { root.addProperty(key, value); markDirty(); }
    public void set(String key, String value) { root.addProperty(key, value); markDirty(); }
}
