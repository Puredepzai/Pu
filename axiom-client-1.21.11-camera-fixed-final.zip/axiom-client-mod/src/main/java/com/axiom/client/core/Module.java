package com.axiom.client.core;

import net.minecraft.client.MinecraftClient;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;

public abstract class Module {
    private final String id;
    private final String name;
    private boolean enabled;

    protected Module(String id, String name) { this.id = id; this.name = name; }

    public final void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;
        this.enabled = enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public final void toggle() { setEnabled(!enabled); }
    public boolean isEnabled() { return enabled; }
    public String id() { return id; }
    public String name() { return name; }

    protected void onEnable() {}
    protected void onDisable() {}
    public void tick(MinecraftClient client) {}
    public void render(MinecraftClient client, WorldRenderContext context) {}
}
