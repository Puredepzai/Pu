package com.axiom.client.core;

import com.axiom.client.module.*;
import net.minecraft.client.MinecraftClient;
import java.util.*;

public final class ModuleManager {
    private final Map<String, Module> modules = new LinkedHashMap<>();

    public void registerDefaults() {
        register(new BaseFinder());
        register(new ChestESP());
        register(new TracerESP());
        register(new ItemESP());
        register(new MobESP());
        register(new Fullbright());
        register(new OreESP());
        register(new AutoTotem());
        register(new Hit());
        register(new SlowSwing());
        register(new BlockESP());
        register(new PlayerESP());
        register(new SmoothChunk());
        register(new UncapFPS());
        loadStates();
    }

    public void register(Module module) { modules.put(module.id(), module); }
    public Collection<Module> all() { return Collections.unmodifiableCollection(modules.values()); }
    public Module get(String id) { return modules.get(id); }

    public void tick(MinecraftClient client) { modules.values().forEach(m -> m.tick(client)); }
    public void loadStates() {
        modules.forEach((id, m) -> m.setEnabled(com.axiom.client.AxiomClient.config().getBoolean("module." + id + ".enabled", false)));
    }
}
