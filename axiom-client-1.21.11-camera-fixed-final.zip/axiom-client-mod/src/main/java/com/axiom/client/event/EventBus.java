package com.axiom.client.event;

import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

public final class EventBus {
    private final CopyOnWriteArrayList<Consumer<Object>> listeners = new CopyOnWriteArrayList<>();

    public void subscribe(Consumer<Object> listener) { listeners.add(listener); }
    public void unsubscribe(Consumer<Object> listener) { listeners.remove(listener); }
    public void post(Object event) { listeners.forEach(l -> l.accept(event)); }
}
