package com.axiom.client.gui;

import com.axiom.client.AxiomClient;
import com.axiom.client.core.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import java.util.*;

public final class AxiomScreen extends Screen {
    private final Screen parent;
    private final List<ButtonWidget> buttons = new ArrayList<>();

    public AxiomScreen(Screen parent) {
        super(Text.literal("Axiom Client"));
        this.parent = parent;
    }

    @Override protected void init() {
        buttons.clear();
        int y=35;
        for (Module m : AxiomClient.modules().all()) {
            ButtonWidget b = ButtonWidget.builder(label(m), btn -> {
                m.toggle();
                AxiomClient.config().set("module."+m.id()+".enabled", m.isEnabled());
                btn.setMessage(label(m));
            }).dimensions(width/2-120,y,240,20).build();
            addDrawableChild(b);
            buttons.add(b);
            y += 24;
            if (y > height-50) break;
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Đóng"), b -> close())
                .dimensions(width/2-120,height-28,240,20).build());
    }

    private Text label(Module m) { return Text.literal((m.isEnabled() ? "[ON] " : "[OFF] ") + m.name()); }

    @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width/2, 12, 0xFFFFFFFF);
        super.render(ctx,mouseX,mouseY,delta);
    }

    @Override public void close() {
        if (client != null) client.setScreen(parent);
    }

    @Override public boolean shouldPause() { return false; }
}
