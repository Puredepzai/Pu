package com.axiom.client.input;

import com.axiom.client.AxiomClient;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class KeybindManager {
    private static KeyBinding menu;

    public static void init() {
        int key = AxiomClient.config().getInt("keybind.menu", GLFW.GLFW_KEY_RIGHT_SHIFT);
        // Minecraft 1.21.11 changed KeyBinding's category parameter from a String
        // to KeyBinding.Category. Using the current API avoids the NoSuchMethodError
        // seen when a 1.21.1-compiled mod is loaded on 1.21.11.
        menu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.axiom.menu",
                InputUtil.Type.KEYSYM,
                key,
                KeyBinding.Category.MISC));
    }

    public static void tick(MinecraftClient client) {
        if (menu == null) return;
        while (menu.wasPressed()) AxiomClient.openScreen();
    }
}
