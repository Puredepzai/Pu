package com.axiom.client.mixin;

import com.axiom.client.AxiomClient;
import com.axiom.client.module.Hit;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin {
    @Inject(method = "getReachDistance", at = @At("RETURN"), cancellable = true)
    private void axiom$reach(CallbackInfoReturnable<Float> cir) {
        var module = AxiomClient.modules().get("hit");
        if (module instanceof Hit hit && module.isEnabled()) {
            cir.setReturnValue((float) hit.reach());
        }
    }
}
