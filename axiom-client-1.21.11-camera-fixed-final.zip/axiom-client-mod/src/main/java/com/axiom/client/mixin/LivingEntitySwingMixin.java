package com.axiom.client.mixin;

import com.axiom.client.AxiomClient;
import com.axiom.client.module.SlowSwing;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class LivingEntitySwingMixin {
    @Unique private long axiom$nextSwing;

    @Inject(method = "swingHand(Lnet/minecraft/util/Hand;)V", at = @At("HEAD"), cancellable = true)
    private void axiom$slowSwing(Hand hand, CallbackInfo ci) {
        if (!((Object)this instanceof ClientPlayerEntity)) return;
        var module = AxiomClient.modules().get("slow_swing");
        if (!(module instanceof SlowSwing slow) || !module.isEnabled()) return;
        long now = System.currentTimeMillis();
        if (now < axiom$nextSwing) {
            ci.cancel();
            return;
        }
        axiom$nextSwing = now + slow.delayMillis();
    }
}
