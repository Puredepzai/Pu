package com.axiom.client.module;

import com.axiom.client.core.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

public final class AutoTotem extends Module {
    private int cooldown;

    public AutoTotem() { super("auto_totem","AutoTotem"); }

    @Override public void tick(MinecraftClient client) {
        if (client.player == null || cooldown-- > 0) return;
        if (client.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;

        int slot = findInventoryTotem(client.player);
        if (slot < 0) return;

        if (client.interactionManager != null) {
            client.interactionManager.clickSlot(client.player.currentScreenHandler.syncId, slot, 40,
                    SlotActionType.SWAP, client.player);
            cooldown = 4;
        }
    }

    private int findInventoryTotem(ClientPlayerEntity p) {
        // Main inventory first (screen slots 9..35), then hotbar (36..44).
        for (int i=9;i<36;i++) if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) return i;
        for (int i=0;i<9;i++) if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) return i+36;
        return -1;
    }
}
