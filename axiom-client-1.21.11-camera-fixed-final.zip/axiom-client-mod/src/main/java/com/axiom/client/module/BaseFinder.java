package com.axiom.client.module;

import com.axiom.client.core.Module;
import com.axiom.client.render.RenderUtil;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.*;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;
import java.util.concurrent.*;

/**
 * Server-friendly base detector.
 *
 * Important limitation: this only analyzes chunk data that the Minecraft client
 * has actually received/loaded. It does not request hidden chunks, bypass server
 * protections, or inspect server-side/unloaded data.
 */
public final class BaseFinder extends Module {
    private static final Set<Class<?>> STORAGE_ENTITIES = Set.of(
            ChestBlockEntity.class, EnderChestBlockEntity.class,
            ShulkerBoxBlockEntity.class, HopperBlockEntity.class
    );

    private static final Set<Class<?>> UTILITY_ENTITIES = Set.of(
            FurnaceBlockEntity.class, BlastFurnaceBlockEntity.class,
            SmokerBlockEntity.class, EnchantingTableBlockEntity.class,
            BeaconBlockEntity.class, MobSpawnerBlockEntity.class
    );

    private final ExecutorService executor = Executors.newFixedThreadPool(2, r -> {
        Thread t = new Thread(r, "axiom-basefinder");
        t.setDaemon(true);
        return t;
    });

    private final ConcurrentMap<Long, Finding> findings = new ConcurrentHashMap<>();
    private final Set<Long> queued = ConcurrentHashMap.newKeySet();
    private int cursor;

    public BaseFinder() {
        super("base_finder", "BaseFinder");
    }

    @Override
    public void onDisable() {
        findings.clear();
        queued.clear();
    }

    @Override
    public void tick(MinecraftClient client) {
        if (client.world == null || client.player == null) return;

        int radius = MathHelper.clamp(
                ModuleSettings.integer(id(), "radius", 16), 4, 32);
        int interval = MathHelper.clamp(
                ModuleSettings.integer(id(), "intervalTicks", 15), 5, 200);
        int budget = MathHelper.clamp(
                ModuleSettings.integer(id(), "chunksPerCycle", 2), 1, 4);

        if (client.player.age % interval != 0) return;

        ChunkPos center = new ChunkPos(client.player.getBlockPos());
        List<ChunkPos> candidates = nearby(center, radius);

        for (int i = 0; i < budget && !candidates.isEmpty(); i++) {
            ChunkPos cp = candidates.get(Math.floorMod(cursor++, candidates.size()));

            // Never force-load chunks on a server. Only inspect data already present.
            if (!client.world.isChunkLoaded(cp.x, cp.z)) continue;

            long key = cp.toLong();
            if (!queued.add(key)) continue;

            WorldChunk chunk = client.world.getChunk(cp.x, cp.z);
            Snapshot snap = snapshot(chunk);
            executor.submit(() -> score(snap));
        }

        findings.keySet().removeIf(k -> {
            ChunkPos p = new ChunkPos(k);
            return Math.abs(p.x - center.x) > radius + 2
                    || Math.abs(p.z - center.z) > radius + 2;
        });
    }

    private List<ChunkPos> nearby(ChunkPos center, int radius) {
        List<ChunkPos> out = new ArrayList<>((radius * 2 + 1) * (radius * 2 + 1));
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                out.add(new ChunkPos(center.x + dx, center.z + dz));
            }
        }

        out.sort(Comparator.comparingInt(
                p -> Math.abs(p.x - center.x) + Math.abs(p.z - center.z)));
        return out;
    }

    /**
     * Snapshot is made on the client thread so Minecraft's world/chunk objects
     * are not read concurrently. The CPU-heavy scoring happens off-thread.
     */
    private Snapshot snapshot(WorldChunk chunk) {
        Map<String, Integer> counts = new HashMap<>();
        List<Evidence> evidence = new ArrayList<>();

        for (BlockEntity be : chunk.getBlockEntities().values()) {
            Block block = be.getCachedState().getBlock();
            String name = block.getName().getString();

            if (STORAGE_ENTITIES.stream().anyMatch(c -> c.isInstance(be))) {
                counts.merge("storage", 1, Integer::sum);
                evidence.add(new Evidence(be.getPos().toImmutable(), name, 6.0));
            } else if (UTILITY_ENTITIES.stream().anyMatch(c -> c.isInstance(be))) {
                counts.merge("utility", 1, Integer::sum);
                evidence.add(new Evidence(be.getPos().toImmutable(), name, utilityWeight(be)));
            }
        }

        // Optional cheap block scan around already discovered block entities.
        // This improves detection of redstone/obsidian/portal infrastructure
        // without scanning the entire 1.21.11 chunk every tick.
        boolean nearbyScan = ModuleSettings.bool(id(), "nearbyBlockScan", true);
        if (nearbyScan) {
            Set<BlockPos> seen = new HashSet<>();
            for (Evidence e : evidence) {
                for (BlockPos p : BlockPos.iterateOutwards(e.pos(), 4, 4, 4)) {
                    if (!new ChunkPos(p).equals(chunk.getPos()) || !seen.add(p)) continue;
                    Block b = chunk.getBlockState(p).getBlock();
                    double w = blockWeight(b);
                    if (w > 0) {
                        String key = blockCategory(b);
                        counts.merge(key, 1, Integer::sum);
                        evidence.add(new Evidence(p.toImmutable(), b.getName().getString(), w));
                    }
                }
            }
        }

        return new Snapshot(chunk.getPos(), List.copyOf(evidence), Map.copyOf(counts));
    }

    private double utilityWeight(BlockEntity be) {
        if (be instanceof MobSpawnerBlockEntity) return 5.0;
        if (be instanceof BeaconBlockEntity) return 4.0;
        if (be instanceof EnchantingTableBlockEntity) return 3.0;
        return 2.0;
    }

    private double blockWeight(Block b) {
        if (b == Blocks.OBSIDIAN || b == Blocks.CRYING_OBSIDIAN) return 2.0;
        if (b == Blocks.REDSTONE_BLOCK) return 2.0;
        if (b == Blocks.REPEATER || b == Blocks.COMPARATOR) return 1.5;
        if (b == Blocks.HOPPER) return 2.0;
        if (b == Blocks.NETHER_PORTAL) return 2.0;
        if (b == Blocks.ANVIL) return 1.5;
        if (b == Blocks.ENCHANTING_TABLE) return 2.5;
        if (b == Blocks.BEACON) return 3.0;
        return 0;
    }

    private String blockCategory(Block b) {
        if (b == Blocks.OBSIDIAN || b == Blocks.CRYING_OBSIDIAN) return "obsidian";
        if (b == Blocks.REDSTONE_BLOCK || b == Blocks.REPEATER
                || b == Blocks.COMPARATOR) return "redstone";
        if (b == Blocks.NETHER_PORTAL) return "portal";
        return "utility_blocks";
    }

    private void score(Snapshot s) {
        try {
            if (s.evidence().isEmpty()) {
                findings.remove(s.chunk().toLong());
                return;
            }

            double raw = 0;
            for (double w : s.evidence().stream().mapToDouble(Evidence::weight).toArray()) {
                raw += Math.min(w, 6.0);
            }

            // Dense evidence close together is more interesting than isolated
            // naturally generated structures.
            double clusterBonus = clusterBonus(s.evidence());
            double densityBonus = Math.min(25.0, s.evidence().size() * 0.75);
            double confidence = Math.min(100.0, raw * 4.0 + clusterBonus + densityBonus);

            int threshold = MathHelper.clamp(
                    ModuleSettings.integer(id(), "minScore", 35), 1, 100);

            if (confidence >= threshold) {
                Evidence focus = s.evidence().stream()
                        .max(Comparator.comparingDouble(Evidence::weight))
                        .orElse(s.evidence().get(0));

                findings.put(s.chunk().toLong(), new Finding(
                        s.chunk(), focus.pos(), confidence,
                        focus.name(), Map.copyOf(s.counts()),
                        s.evidence().size()));
            } else {
                findings.remove(s.chunk().toLong());
            }
        } finally {
            queued.remove(s.chunk().toLong());
        }
    }

    private double clusterBonus(List<Evidence> list) {
        double bonus = 0;
        int pairs = 0;
        int radius = MathHelper.clamp(
                ModuleSettings.integer(id(), "clusterRadius", 12), 4, 24);

        for (int i = 0; i < list.size() && pairs < 120; i++) {
            for (int j = i + 1; j < list.size() && pairs < 120; j++) {
                if (list.get(i).pos().getSquaredDistance(list.get(j).pos()) <= radius * radius) {
                    bonus += 2.0;
                    pairs++;
                }
            }
        }
        return Math.min(30.0, bonus);
    }

    @Override
    public void render(MinecraftClient client,
                       net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        if (client.world == null || client.player == null
                || context.matrixStack() == null || context.consumers() == null) return;

        Vec3d cam = MinecraftClient.getInstance().gameRenderer.getCamera().getCameraPos();
        int limit = MathHelper.clamp(
                ModuleSettings.integer(id(), "renderLimit", 16), 1, 32);
        double maxDistance = MathHelper.clamp(
                ModuleSettings.decimal(id(), "renderDistance", 256.0), 32.0, 512.0);

        List<Finding> sorted = findings.values().stream()
                .sorted(Comparator.comparingDouble(Finding::confidence).reversed())
                .limit(limit)
                .toList();

        context.matrixStack().push();
        context.matrixStack().translate(-cam.x, -cam.y, -cam.z);

        for (Finding f : sorted) {
            if (f.focus().getSquaredDistance(client.player.getPos())
                    > maxDistance * maxDistance) continue;

            // Smaller evidence box instead of outlining the entire world-height
            // chunk, making the result much easier to read on a phone.
            BlockPos p = f.focus();
            RenderUtil.box(context.matrixStack(), context.consumers(),
                    new Box(p).expand(0.08),
                    0.95f, 0.25f, 0.2f, 1.0f);

            double x1 = f.chunk().getStartX();
            double z1 = f.chunk().getStartZ();
            double x2 = x1 + 16;
            double z2 = z1 + 16;
            double y = MathHelper.clamp(p.getY(), client.world.getBottomY(), client.world.getTopY());

            RenderUtil.box(context.matrixStack(), context.consumers(),
                    new Box(x1, y, z1, x2, y + 0.05, z2),
                    1.0f, 0.35f, 0.15f, 0.55f);
        }

        context.matrixStack().pop();
    }

    public Collection<Finding> findings() {
        return Collections.unmodifiableCollection(findings.values());
    }

    public Optional<Finding> nearest(MinecraftClient client) {
        if (client.player == null) return Optional.empty();
        return findings.values().stream().min(
                Comparator.comparingDouble(f ->
                        f.focus().getSquaredDistance(client.player.getPos())));
    }

    public record Snapshot(
            ChunkPos chunk,
            List<Evidence> evidence,
            Map<String, Integer> counts) {}

    public record Evidence(
            BlockPos pos,
            String name,
            double weight) {}

    public record Finding(
            ChunkPos chunk,
            BlockPos focus,
            double confidence,
            String strongestEvidence,
            Map<String, Integer> evidence,
            int evidenceCount) {}
}
