package com.axiom.client.module;

import com.axiom.client.core.Module;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import com.axiom.client.render.RenderUtil;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.ChunkPos;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class BlockESP extends Module {
    private static final Set<Block> TARGETS = Set.of(
            Blocks.CHEST, Blocks.ENDER_CHEST, Blocks.SHULKER_BOX, Blocks.SPAWNER,
            Blocks.HOPPER, Blocks.REDSTONE_BLOCK
    );
    private final Set<BlockPos> cache = ConcurrentHashMap.newKeySet();
    private long lastScan;

    public BlockESP() { super("block_esp","BlockESP"); }

    @Override public void onDisable() { cache.clear(); }

    @Override public void tick(MinecraftClient client) {
        if (client.world == null || client.player == null) return;
        int dist = MathHelperCompat.clamp(ModuleSettings.integer(id(),"distance",64),16,256);
        if (client.player.age - lastScan < ModuleSettings.integer(id(),"scanInterval",10)) return;
        lastScan = client.player.age;
        int chunkRadius = Math.max(1, (dist + 15) >> 4);
        ChunkPos c = new ChunkPos(client.player.getBlockPos());
        Set<BlockPos> next = new HashSet<>();
        for (int dx=-chunkRadius;dx<=chunkRadius;dx++) for (int dz=-chunkRadius;dz<=chunkRadius;dz++) {
            if (!client.world.isChunkLoaded(c.x+dx,c.z+dz)) continue;
            for (BlockEntity be : client.world.getChunk(c.x+dx,c.z+dz).getBlockEntities().values()) {
                Block b = be.getCachedState().getBlock();
                if (TARGETS.contains(b) && be.getPos().getSquaredDistance(client.player.getPos()) <= (double)dist*dist)
                    next.add(be.getPos().toImmutable());
            }
        }
        cache.clear(); cache.addAll(next);
    }

    public Set<BlockPos> targets() { return Collections.unmodifiableSet(cache); }

    @Override public void render(MinecraftClient client, net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        if (client.player == null || context.matrixStack() == null || context.consumers() == null) return;
        Vec3d cam = MinecraftClient.getInstance().gameRenderer.getCamera().getCameraPos();
        context.matrixStack().push();
        context.matrixStack().translate(-cam.x, -cam.y, -cam.z);
        for (BlockPos pos : cache) {
            RenderUtil.box(context.matrixStack(), context.consumers(), new Box(pos), 0.2f, 0.8f, 1.0f, 1.0f);
        }
        context.matrixStack().pop();
    }


    private static final class MathHelperCompat {
        static int clamp(int v,int min,int max){return Math.max(min,Math.min(max,v));}
    }
}
