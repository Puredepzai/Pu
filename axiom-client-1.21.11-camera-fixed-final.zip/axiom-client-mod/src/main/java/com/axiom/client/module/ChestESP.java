package com.axiom.client.module;

import com.axiom.client.core.Module;
import com.axiom.client.render.RenderUtil;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Highlights chest-like storage in chunks already loaded by the client. */
public final class ChestESP extends Module {
    private final Set<BlockPos> cache = ConcurrentHashMap.newKeySet();
    private long lastScan;

    public ChestESP() { super("chest_esp", "Chest ESP"); }

    @Override public void onDisable() { cache.clear(); }

    @Override public void tick(MinecraftClient client) {
        if (client.world == null || client.player == null) return;
        int interval = Math.max(3, ModuleSettings.integer(id(), "scanInterval", 8));
        if (client.player.age - lastScan < interval) return;
        lastScan = client.player.age;
        int dist = Math.max(16, Math.min(256, ModuleSettings.integer(id(), "distance", 96)));
        int cr = Math.max(1, (dist + 15) >> 4);
        ChunkPos c = new ChunkPos(client.player.getBlockPos());
        Set<BlockPos> next = new HashSet<>();
        double maxSq = (double) dist * dist;
        for (int dx = -cr; dx <= cr; dx++) for (int dz = -cr; dz <= cr; dz++) {
            if (!client.world.isChunkLoaded(c.x + dx, c.z + dz)) continue;
            for (BlockEntity be : client.world.getChunk(c.x + dx, c.z + dz).getBlockEntities().values()) {
                var b = be.getCachedState().getBlock();
                if ((b == Blocks.CHEST || b == Blocks.ENDER_CHEST || b == Blocks.SHULKER_BOX)
                        && be.getPos().getSquaredDistance(client.player.getPos()) <= maxSq) {
                    next.add(be.getPos().toImmutable());
                }
            }
        }
        cache.clear(); cache.addAll(next);
    }

    public Set<BlockPos> targets() { return Collections.unmodifiableSet(cache); }

    @Override public void render(MinecraftClient client, net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        if (client.player == null || context.matrixStack() == null || context.consumers() == null) return;
        Vec3d cam = MinecraftClient.getInstance().gameRenderer.getCamera().getCameraPos();
        context.matrixStack().push();
        context.matrixStack().translate(-cam.x, -cam.y, -cam.z);
        for (BlockPos pos : cache) RenderUtil.box(context.matrixStack(), context.consumers(), new Box(pos), 1f, 0.75f, 0.1f, 1f);
        context.matrixStack().pop();
    }
}
