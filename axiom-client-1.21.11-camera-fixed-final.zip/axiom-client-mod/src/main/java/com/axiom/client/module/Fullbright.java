package com.axiom.client.module;

import com.axiom.client.core.Module;
import net.minecraft.client.MinecraftClient;

/** Client-only brightness change; restores the previous gamma value when disabled. */
public final class Fullbright extends Module {
    private Double previous;
    public Fullbright() { super("fullbright", "Fullbright"); }
    @Override protected void onEnable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.options != null) {
            previous = c.options.getGamma().getValue();
            c.options.getGamma().setValue(16.0);
        }
    }
    @Override protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (previous != null && c.options != null) c.options.getGamma().setValue(previous);
        previous = null;
    }
}
