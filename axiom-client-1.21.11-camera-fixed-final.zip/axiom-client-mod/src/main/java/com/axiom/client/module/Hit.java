package com.axiom.client.module;

import com.axiom.client.core.Module;

public final class Hit extends Module {
    public Hit() { super("hit","Hit"); }
    public double reach() { return Math.max(3.0, Math.min(6.0, ModuleSettings.decimal(id(),"reach",3.0))); }
}
