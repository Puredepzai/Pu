package com.axiom.client.module;

import com.axiom.client.core.Module;
import com.axiom.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public final class ItemESP extends Module {
    public ItemESP() { super("item_esp", "Item ESP"); }
    @Override public void render(MinecraftClient client, net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        if (client.player == null || client.world == null || context.matrixStack() == null || context.consumers() == null) return;
        double dist = Math.max(16, Math.min(128, ModuleSettings.integer(id(), "distance", 64)));
        Vec3d cam = MinecraftClient.getInstance().gameRenderer.getCamera().getCameraPos();
        context.matrixStack().push(); context.matrixStack().translate(-cam.x, -cam.y, -cam.z);
        for (ItemEntity e : client.world.getEntitiesByClass(ItemEntity.class, client.player.getBoundingBox().expand(dist), x -> true)) {
            RenderUtil.box(context.matrixStack(), context.consumers(), e.getBoundingBox(), 0.3f, 1f, 0.3f, 0.9f);
        }
        context.matrixStack().pop();
    }
}
