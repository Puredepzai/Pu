package com.axiom.client.module;

import com.axiom.client.core.Module;
import com.axiom.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class MobESP extends Module {
    public MobESP() { super("mob_esp", "Mob ESP"); }
    @Override public void render(MinecraftClient client, net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        if (client.player == null || client.world == null || context.matrixStack() == null || context.consumers() == null) return;
        double dist = Math.max(16, Math.min(192, ModuleSettings.integer(id(), "distance", 96)));
        Vec3d cam = MinecraftClient.getInstance().gameRenderer.getCamera().getCameraPos();
        context.matrixStack().push(); context.matrixStack().translate(-cam.x, -cam.y, -cam.z);
        for (LivingEntity e : client.world.getEntitiesByClass(LivingEntity.class, client.player.getBoundingBox().expand(dist), x -> true)) {
            if (e == client.player || e instanceof PlayerEntity || e.isSpectator() || e.isInvisible()) continue;
            RenderUtil.box(context.matrixStack(), context.consumers(), e.getBoundingBox(), 1f, 0.25f, 0.25f, 0.75f);
        }
        context.matrixStack().pop();
    }
}
