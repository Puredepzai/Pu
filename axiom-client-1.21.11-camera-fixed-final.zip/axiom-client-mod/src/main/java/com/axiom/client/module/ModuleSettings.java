package com.axiom.client.module;

import com.axiom.client.AxiomClient;

public final class ModuleSettings {
    private ModuleSettings() {}
    public static boolean bool(String id, String key, boolean def) {
        return AxiomClient.config().getBoolean("module."+id+"."+key, def);
    }
    public static int integer(String id, String key, int def) {
        return AxiomClient.config().getInt("module."+id+"."+key, def);
    }
    public static double decimal(String id, String key, double def) {
        return AxiomClient.config().getDouble("module."+id+"."+key, def);
    }
    public static void set(String id, String key, boolean v) {
        AxiomClient.config().set("module."+id+"."+key, v);
    }
    public static void set(String id, String key, int v) {
        AxiomClient.config().set("module."+id+"."+key, v);
    }
    public static void set(String id, String key, double v) {
        AxiomClient.config().set("module."+id+"."+key, v);
    }
}
