package com.axiom.client.module;

import com.axiom.client.core.Module;
import com.axiom.client.render.RenderUtil;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Finds ore blocks only in already loaded client chunks and within a small radius. */
public final class OreESP extends Module {
    private static final Set<Block> ORES = Set.of(Blocks.COAL_ORE, Blocks.IRON_ORE, Blocks.COPPER_ORE,
            Blocks.GOLD_ORE, Blocks.REDSTONE_ORE, Blocks.LAPIS_ORE, Blocks.DIAMOND_ORE,
            Blocks.EMERALD_ORE, Blocks.DEEPSLATE_COAL_ORE, Blocks.DEEPSLATE_IRON_ORE,
            Blocks.DEEPSLATE_COPPER_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.DEEPSLATE_REDSTONE_ORE,
            Blocks.DEEPSLATE_LAPIS_ORE, Blocks.DEEPSLATE_DIAMOND_ORE, Blocks.DEEPSLATE_EMERALD_ORE,
            Blocks.NETHER_QUARTZ_ORE, Blocks.NETHER_GOLD_ORE, Blocks.ANCIENT_DEBRIS);
    private final Set<BlockPos> cache = ConcurrentHashMap.newKeySet();
    private long lastScan;
    public OreESP() { super("ore_esp", "Ore ESP"); }
    @Override public void onDisable() { cache.clear(); }
    @Override public void tick(MinecraftClient client) {
        if (client.world == null || client.player == null) return;
        int interval = Math.max(10, Math.min(100, ModuleSettings.integer(id(), "scanInterval", 30)));
        if (client.player.age - lastScan < interval) return;
        lastScan = client.player.age;
        int r = Math.max(4, Math.min(24, ModuleSettings.integer(id(), "radius", 12)));
        BlockPos center = client.player.getBlockPos(); Set<BlockPos> next = new HashSet<>();
        for (int x=-r;x<=r;x++) for(int y=-r;y<=r;y++) for(int z=-r;z<=r;z++) {
            BlockPos p = center.add(x,y,z); if (client.world.getBlockState(p).getBlock() instanceof Block b && ORES.contains(b)) next.add(p.toImmutable());
        }
        cache.clear(); cache.addAll(next);
    }
    @Override public void render(MinecraftClient client, net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        if (context.matrixStack()==null || context.consumers()==null) return; Vec3d cam=MinecraftClient.getInstance().gameRenderer.getCamera().getCameraPos();
        context.matrixStack().push(); context.matrixStack().translate(-cam.x,-cam.y,-cam.z);
        for(BlockPos p:cache) RenderUtil.box(context.matrixStack(),context.consumers(),new Box(p),0.2f,0.7f,1f,0.8f);
        context.matrixStack().pop();
    }
}
