package com.axiom.client.module;

import com.axiom.client.core.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import com.axiom.client.render.RenderUtil;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import java.util.*;

public final class PlayerESP extends Module {
    public PlayerESP() { super("player_esp","PlayerESP"); }
    public boolean box(){return ModuleSettings.bool(id(),"box",true);}
    public boolean outline(){return ModuleSettings.bool(id(),"outline",true);}
    public boolean tracer(){return ModuleSettings.bool(id(),"tracer",false);}
    public boolean showName(){return ModuleSettings.bool(id(),"name",true);}
    public boolean distance(){return ModuleSettings.bool(id(),"distance",true);}
    public boolean throughWalls(){return ModuleSettings.bool(id(),"throughWalls",true);}



    @Override public void render(MinecraftClient client, net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        if (client.player == null || context.matrixStack() == null || context.consumers() == null) return;
        Vec3d cam = MinecraftClient.getInstance().gameRenderer.getCamera().getCameraPos();
        context.matrixStack().push();
        context.matrixStack().translate(-cam.x, -cam.y, -cam.z);
        for (AbstractClientPlayerEntity p : targets(client)) {
            Box b = p.getBoundingBox();
            if (box()) RenderUtil.box(context.matrixStack(), context.consumers(), b, 0.3f, 1.0f, 0.3f, 1.0f);
            if (tracer()) RenderUtil.line(context.matrixStack(), context.consumers(),
                    client.player.getCameraPosVec(1.0f), p.getPos().add(0, p.getHeight()*0.5, 0),
                    1.0f, 0.85f, 0.2f, 1.0f);
        }
        context.matrixStack().pop();
    }

    public List<AbstractClientPlayerEntity> targets(MinecraftClient client) {
        if (client.world == null || client.player == null) return List.of();
        return client.world.getPlayers().stream()
                .filter(p -> p != client.player && p.isAlive())
                .toList();
    }
}
