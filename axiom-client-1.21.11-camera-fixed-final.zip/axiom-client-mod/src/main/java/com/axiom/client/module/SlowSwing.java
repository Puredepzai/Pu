package com.axiom.client.module;

import com.axiom.client.core.Module;

public final class SlowSwing extends Module {
    public SlowSwing() { super("slow_swing","SlowSwing"); }
    public long delayMillis() {
        int divider = Math.max(1, Math.min(20, ModuleSettings.integer(id(),"divider",3)));
        return 50L * divider;
    }
}
