package com.axiom.client.module;

import com.axiom.client.core.Module;
import net.minecraft.client.MinecraftClient;

public final class SmoothChunk extends Module {
    public SmoothChunk() { super("smooth_chunk","SmoothChunk"); }
    public int chunkBudget() { return Math.max(1, Math.min(8, ModuleSettings.integer(id(),"chunkBudget",2))); }
    @Override public void tick(MinecraftClient client) {
        // Conservative client-side policy: avoid adding work on every tick.
        // Vanilla's chunk builder remains authoritative; this module only exposes a
        // throttle setting for future renderer mixins rather than polling chunks.
    }
}
