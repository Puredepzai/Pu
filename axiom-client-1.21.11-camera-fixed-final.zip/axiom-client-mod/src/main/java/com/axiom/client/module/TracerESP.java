package com.axiom.client.module;

import com.axiom.client.core.Module;
import com.axiom.client.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class TracerESP extends Module {
    public TracerESP() { super("tracer_esp", "Player Tracers"); }

    @Override public void render(MinecraftClient client, net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        if (client.player == null || client.world == null || context.matrixStack() == null || context.consumers() == null) return;
        Vec3d cam = MinecraftClient.getInstance().gameRenderer.getCamera().getCameraPos();
        double dist = Math.max(16, Math.min(256, ModuleSettings.integer(id(), "distance", 96)));
        context.matrixStack().push();
        context.matrixStack().translate(-cam.x, -cam.y, -cam.z);
        Vec3d from = client.player.getCameraPosVec(1.0f);
        for (PlayerEntity p : client.world.getPlayers()) {
            if (p == client.player || p.isSpectator() || p.getPos().squaredDistanceTo(client.player.getPos()) > dist * dist) continue;
            RenderUtil.line(context.matrixStack(), context.consumers(), from, p.getPos().add(0, p.getHeight() * 0.5, 0), 1f, 0.25f, 0.25f, 0.9f);
        }
        context.matrixStack().pop();
    }
}
