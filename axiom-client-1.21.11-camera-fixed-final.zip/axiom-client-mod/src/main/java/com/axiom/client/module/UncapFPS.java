package com.axiom.client.module;

import com.axiom.client.core.Module;
import net.minecraft.client.MinecraftClient;

public final class UncapFPS extends Module {
    public UncapFPS() { super("uncap_fps","UncapFPS"); }

    @Override protected void onEnable() {
        MinecraftClient client = MinecraftClient.getInstance();
        client.getWindow().setVsync(false);
        client.options.getMaxFps().setValue(260);
    }
    @Override protected void onDisable() {
        MinecraftClient client = MinecraftClient.getInstance();
        client.options.getMaxFps().setValue(60);
    }
}
