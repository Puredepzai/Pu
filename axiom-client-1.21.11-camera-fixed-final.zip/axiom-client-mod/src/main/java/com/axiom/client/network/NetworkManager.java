package com.axiom.client.network;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public final class NetworkManager {
    private static final Identifier ID = Identifier.of("axiom", "client_hello");

    public record ClientHello(String version) implements CustomPayload {
        public static final CustomPayload.Id<ClientHello> TYPE = new CustomPayload.Id<>(ID);
        public static final PacketCodec<RegistryByteBuf, ClientHello> CODEC =
                PacketCodec.tuple(net.minecraft.network.codec.PacketCodecs.STRING,
                        ClientHello::version, ClientHello::new);
        @Override public Id<? extends CustomPayload> getId() { return TYPE; }
    }

    public static void init() {
        PayloadTypeRegistry.playC2S().register(ClientHello.TYPE, ClientHello.CODEC);
    }

    public static void sendHelloIfSupported() {
        if (ClientPlayNetworking.canSend(ClientHello.TYPE)) {
            ClientPlayNetworking.send(new ClientHello("1.0.0"));
        }
    }
}
