package com.axiom.client.render;

import com.axiom.client.AxiomClient;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;

public final class RenderManager {
    public void init() {
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || ctx.matrixStack() == null || ctx.consumers() == null) return;
            for (var module : AxiomClient.modules().all()) {
                if (module.isEnabled()) module.render(client, ctx);
            }
        });
    }
}
