package com.axiom.client.render;

import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public final class RenderUtil {
    private RenderUtil() {}

    public static void box(MatrixStack matrices, VertexConsumerProvider consumers, Box box,
                           float r, float g, float b, float a) {
        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLines());
        WorldRenderer.drawBox(matrices, vc, box, r, g, b, a);
    }

    public static void line(MatrixStack matrices, VertexConsumerProvider consumers,
                            Vec3d from, Vec3d to, float r, float g, float b, float a) {
        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLines());
        Matrix4f m = matrices.peek().getPositionMatrix();
        vc.vertex(m, (float)from.x, (float)from.y, (float)from.z).color(r,g,b,a).normal(0,1,0);
        vc.vertex(m, (float)to.x, (float)to.y, (float)to.z).color(r,g,b,a).normal(0,1,0);
    }
}
